<?php
$message = "";

if (isset($_POST['login'])) {

    $link = mysqli_connect('127.0.0.1', 'root', '', 'Student');

    if (!$link) {
        die('Ошибка подключения к БД');
    }

    mysqli_set_charset($link, 'utf8mb4');

    $login = trim($_POST['login']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $Name = trim($_POST['Name']);
    $secondName = trim($_POST['secondName']);
    $Family = trim($_POST['Family']);
    $age = (int)$_POST['age'];
    $number = trim($_POST['number']);
    $email = trim($_POST['email']);
    $dateFiestEcount = $_POST['dateFiestEcount'];
    $Date = $_POST['Date'];
    $text = trim($_POST['text']);

    $id = random_int(1, 1000000000);

    $stmt = mysqli_prepare($link,
        "INSERT INTO Test
        (id, login, password, Name, secondName, Family,
        age, number, email, dateFiestEcount, Date, text)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
    );

    mysqli_stmt_bind_param($stmt, 'isssssisssss',
        $id, $login, $password, $Name, $secondName,
        $Family, $age, $number, $email,
        $dateFiestEcount, $Date, $text
    );

    if (mysqli_stmt_execute($stmt)) {
        $message = "Данные успешно сохранены! ID: " . $id;
    } else {
        $message = "Ошибка сохранения данных";
    }

    mysqli_stmt_close($stmt);
    mysqli_close($link);
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Форма авторизации</title>
    <link rel="stylesheet" href="style.css">
    <script src="script.js" defer></script>
</head>
<body>

<main>
    <h1>Форма авторизации</h1>

    <form id="form" method="POST">

        <label>Логин
            <input type="text" name="login" required>
        </label>

        <label>Пароль
            <input type="password" name="password"
                   minlength="8" required>
        </label>

        <label>Имя
            <input type="text" name="Name"
                   maxlength="20" required>
        </label>

        <label>Отчество
            <input type="text" name="secondName"
                   maxlength="20" required>
        </label>

        <label>Фамилия
            <input type="text" name="Family"
                   maxlength="50" required>
        </label>

        <label>Возраст
            <input type="number" name="age"
                   min="0" max="999" required>
        </label>

        <label>Номер телефона
            <input type="tel" name="number"
                   maxlength="13" required>
        </label>

        <label>Email
            <input type="email" name="email"
                   maxlength="20" required>
        </label>

        <label>Дата создания аккаунта
            <input type="date" name="dateFiestEcount" required>
        </label>

        <label>Дата
            <input type="date" name="Date" required>
        </label>

        <label>Текст
            <textarea name="text"
                      maxlength="255" required></textarea>
        </label>

        <button type="submit">Отправить</button>

    </form>

    <p id="message">
        <?php echo htmlspecialchars($message); ?>
    </p>

</main>

</body>
</html>
