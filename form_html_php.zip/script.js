const form = document.getElementById("form");
const message = document.getElementById("message");

form.addEventListener("submit", function(event) {

    const data = Object.fromEntries(new FormData(form));

    const letters = /^[А-Яа-яЁёA-Za-z]+(?:[ -][А-Яа-яЁёA-Za-z]+)*$/;

    const errors = {};

    if (!letters.test(data.Name))
        errors.Name = "Некорректное имя";

    if (!letters.test(data.secondName))
        errors.secondName = "Некорректное отчество";

    if (!letters.test(data.Family))
        errors.Family = "Некорректная фамилия";

    if (!/^\d{1,3}$/.test(data.age))
        errors.age = "Некорректный возраст";

    if (!/^\+?\d{7,13}$/.test(data.number))
        errors.number = "Некорректный телефон";

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email))
        errors.email = "Некорректный Email";

    if (!data.login.trim())
        errors.login = "Введите логин";

    if (data.password.length < 8)
        errors.password = "Пароль минимум 8 символов";

    if (!data.dateFiestEcount)
        errors.dateFiestEcount = "Укажите дату создания";

    if (!data.Date)
        errors.Date = "Укажите дату";

    if (!data.text.trim())
        errors.text = "Введите текст";

    for (let key in data) {
        form.elements[key].classList.toggle(
            "invalid", Boolean(errors[key])
        );
    }

    if (Object.keys(errors).length > 0) {
        event.preventDefault();

        message.className = "error";
        message.textContent = Object.values(errors).join(". ");
    }

});
