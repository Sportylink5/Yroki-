const form = document.getElementById("form");
const message = document.getElementById("message");
const result = document.getElementById("result");

form.addEventListener("submit", function (event) {
    event.preventDefault();

    const data = Object.fromEntries(new FormData(form));
    for (let key in data) {
        data[key] = data[key].trim();
    }

    // Проверка имени, отчества и фамилии
    const letters = /^[А-Яа-яЁёA-Za-z]+(?:[ -][А-Яа-яЁёA-Za-z]+)*$/;
    const errors = {};
    if (!letters.test(data.Name) || data.Name.length > 20)
        errors.Name = "Имя: только буквы, до 20 символов.";
    if (!letters.test(data.secondName) || data.secondName.length > 20)
        errors.secondName = "Отчество: только буквы, до 20 символов.";
    if (!letters.test(data.Family) || data.Family.length > 50)
        errors.Family = "Фамилия: только буквы, до 50 символов.";

    // Проверка возраста: целое число, не больше трёх цифр
    if (!/^\d{1,3}$/.test(data.age))
        errors.age = "Возраст: целое число от 0 до 999.";

    // Проверка телефона и электронной почты
    if (!/^\+?\d{7,13}$/.test(data.number) || data.number.length > 13)
        errors.number = "Телефон: от 7 цифр, не более 13 символов.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email) || data.email.length > 20)
        errors.email = "Введите правильный email (до 20 символов).";

    // Проверка обеих дат
    if (!data.dateFiestEcount || !form.elements.dateFiestEcount.validity.valid || data.dateFiestEcount.length > 17)
        errors.dateFiestEcount = "Введите правильную дату создания аккаунта.";
    if (!data.Date || !form.elements.Date.validity.valid || data.Date.length > 17)
        errors.Date = "Введите правильную дату.";

    if (!data.text || data.text.length > 255)
        errors.text = "Введите текст от 1 до 255 символов.";

    // Вывод ошибок всех полей
    for (let key in data) {
        form.elements[key].classList.toggle("invalid", Boolean(errors[key]));
        form.elements[key].setAttribute("aria-invalid", Boolean(errors[key]));
    }
    if (Object.keys(errors).length > 0) {
        message.className = "error";
        message.textContent = Object.values(errors).join(" ");
        result.hidden = true;
        form.elements[Object.keys(errors)[0]].focus();
        return;
    }

    // Случайный ID от 1 до 1000000000 включительно
    const id = Math.floor(Math.random() * 1000000000) + 1;
    data.age = Number(data.age);
    const user = { id: id, ...data };

    message.className = "success";
    message.textContent = "Данные успешно проверены! ID: " + id;
    result.textContent = JSON.stringify(user, null, 2);
    result.hidden = false;
});
